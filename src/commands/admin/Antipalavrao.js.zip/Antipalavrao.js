// 📁 Caminhos e dependências
const fs = require("fs");
const path = require("path");
const stringSimilarity = require("string-similarity");
const { PREFIX } = require("../../config");

// 📁 Caminhos dos arquivos JSON
const filePathStatus = path.resolve(__dirname, "../../../database/statusFiltro.json");
const filePathPalavroes = path.resolve(__dirname, "../../../database/palavroes.json");

// 📍 Grupo para logs
const LOG_GROUP_ID = "120363420832736605@g.us";

function isGroup(jid = "") {
  return jid.endsWith("@g.us");
}

async function isAdmin(userJid, groupJid, sock) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    const participant = metadata.participants.find(p => p.id === userJid);
    return participant?.admin === "admin" || participant?.admin === "superadmin";
  } catch (err) {
    console.error("Erro ao verificar admin:", err);
    return false;
  }
}

function lerStatus() {
  try {
    const data = fs.readFileSync(filePathStatus, "utf8");
    const json = JSON.parse(data);
    return json.ativado;
  } catch (err) {
    console.error("Erro ao ler status do filtro:", err);
    return false;
  }
}

function salvarStatus(status) {
  const json = { ativado: status };
  fs.writeFileSync(filePathStatus, JSON.stringify(json, null, 2));
}

function getPalavroes() {
  try {
    const data = fs.readFileSync(filePathPalavroes, "utf8");
    const json = JSON.parse(data);
    return json.global || [];
  } catch (err) {
    console.error("Erro ao carregar palavrões:", err);
    return [];
  }
}

function temPalavraoComSimilaridade(mensagem, listaPalavroes, threshold = 0.82) {
  const texto = mensagem.toLowerCase();
  const palavrasTexto = texto.split(/\s|\.|,|!|\?|\n|"|'/).filter(Boolean);

  return listaPalavroes.some(palavrao => {
    return palavrasTexto.some(palavra => {
      return stringSimilarity.compareTwoStrings(palavra, palavrao.toLowerCase()) >= threshold;
    });
  });
}

module.exports = {
  name: "antipalavrao",
  description: "Ativa ou desativa o filtro de palavrões",
  commands: ["antipalavrao"],
  usage: `${PREFIX}antipalavrao 1 ou ${PREFIX}antipalavrao 0`,

  handle: async ({ args, remoteJid, socket, sendSuccessReply, sendWarningReply, sendErrorReply, userJid }) => {
    try {
      const donoJid = "55991888116@s.whatsapp.net";
      const isUserAdmin = await isAdmin(userJid, remoteJid, socket);
      const isOwner = userJid === donoJid;

      if (!isGroup(remoteJid)) return sendWarningReply("⚠️ Este comando só pode ser usado em grupos.");
      if (!isUserAdmin && !isOwner) return sendWarningReply("🚫 Apenas administradores ou o dono do bot podem usar este comando.");

      if (!args[0]) {
        return sendWarningReply(
          ` *ANTIPALAVRÃO* ❖─╮\n` +
          `│ Use um dos comandos abaixo:\n` +
          `│\n` +
          `│ • /antipalavrao 1  ➜ Ativar\n` +
          `│ • /antipalavrao 0  ➜ Desativar\n` +
          `╰───────────────────────╯`
        );
      }

      const valor = args[0].trim();
      if (valor === "1") {
        salvarStatus(true);
        return sendSuccessReply(" Filtro de palavrões ativado!");
      } else if (valor === "0") {
        salvarStatus(false);
        return sendSuccessReply(" Filtro de palavrões desativado.");
      } else {
        return sendWarningReply("❗ Valor inválido. Use /antipalavrao 1 ou /antipalavrao 0.");
      }
    } catch (err) {
      console.error("Erro no comando antipalavrao:", err);
      return sendErrorReply("❌ Erro ao processar o comando.");
    }
  },

  filtroAtivado: () => lerStatus(),

  processMessage: async (message, sock) => {
    try {
      if (!lerStatus()) return;
      if (!message || !message.key || !message.key.remoteJid) return;

      const from = message.key.remoteJid;
      if (!isGroup(from)) return;

      const texto = message.message?.conversation || message.message?.extendedTextMessage?.text || "";
      const textoLimpo = texto.toLowerCase();
      const palavroes = getPalavroes();

      const contemPalavrao = temPalavraoComSimilaridade(textoLimpo, palavroes);
      if (contemPalavrao) {
        try {
          // Deletar mensagem
          await sock.sendMessage(from, {
            delete: {
              remoteJid: from,
              fromMe: false,
              id: message.key.id,
              participant: message.key.participant || message.key.remoteJid,
            },
          });

          // Notificar o grupo
          await sock.sendMessage(from, {
            text: `⚠️ Olá @${(message.key.participant || message.key.remoteJid).split("@")[0]}, sua mensagem foi removida por conter palavrões.`,
            mentions: [message.key.participant || message.key.remoteJid],
          });

          // Log para o grupo de logs
          await sock.sendMessage(LOG_GROUP_ID, {
            text:
              `🚨 Palavra ofensiva detectada!\n` +
              `👤 Usuário: @${(message.key.participant || message.key.remoteJid).split("@")[0]}\n` +
              `🗑️ Mensagem: "${texto}"\n` +
              `📍 Grupo: ${from}`,
            mentions: [message.key.participant || message.key.remoteJid],
          });

          console.log("🚨 Palavra proibida detectada e mensagem deletada.");
        } catch (error) {
          console.error("Erro ao deletar mensagem com palavrão:", error);
        }
      }
    } catch (err) {
      console.error("Erro interno no processMessage:", err);
    }
  }
};
