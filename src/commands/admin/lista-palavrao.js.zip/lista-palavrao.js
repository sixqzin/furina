const fs = require("fs");
const path = require("path");
const { PREFIX } = require("../../config");

const filePath = path.resolve(__dirname, "../../../database/palavroes.json");

function isGroup(jid = "") {
  return jid.endsWith("@g.us");
}

async function isAdmin(userJid, groupJid, sock) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    const participant = metadata.participants.find(p => p.id === userJid);
    return participant?.admin === "admin" || participant?.admin === "superadmin";
  } catch (err) {
    console.error("Erro ao verificar admin:", err);
    return false;
  }
}

module.exports = {
  commands: ["lista-palavrao"],
  description: "Lista todos os palavrões registrados",
  usage: `${PREFIX}lista-palavrao`,

  handle: async ({
    remoteJid,
    socket,
    sendSuccessReply,
    sendWarningReply,
    userJid,
  }) => {
    try {
      if (!isGroup(remoteJid)) {
        return sendWarningReply("❌ Este comando só pode ser usado em grupos.");
      }

      const donoJid = "5511999999999@s.whatsapp.net"; // <---- SEU NÚMERO AQUI
      const admin = await isAdmin(userJid, remoteJid, socket);
      const isBotOwner = userJid === donoJid;

      if (!admin && !isBotOwner) {
        return sendWarningReply("🚫 Apenas administradores ou o dono do bot podem usar este comando.");
      }

      if (!fs.existsSync(filePath)) {
        return sendWarningReply("❌ Nenhuma palavra foi adicionada ainda.");
      }

      const data = fs.readFileSync(filePath, "utf8");
      const json = JSON.parse(data);
      const palavras = json.global || [];

      if (!palavras.length) {
        return sendWarningReply("❌ Nenhuma palavra está na lista.");
      }

      const lista = palavras.map((p, i) => `• ${i + 1}. ${p}`).join("\n");
      return sendSuccessReply(`📃 *Lista de palavrões:*\n\n${lista}`);
    } catch (err) {
      console.error("Erro ao listar palavrões:", err);
      return sendWarningReply("❌ Erro ao listar as palavras.");
    }
  },
};
