const fs = require("fs");
const path = require("path");
const { PREFIX } = require("../../config");

const filePath = path.resolve(__dirname, "../../../database/palavroes.json");

function isGroup(jid = "") {
  return jid.endsWith("@g.us");
}

async function isAdmin(userJid, groupJid, sock) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    const participant = metadata.participants.find(p => p.id === userJid);
    return participant?.admin === "admin" || participant?.admin === "superadmin";
  } catch (err) {
    console.error("Erro ao verificar admin:", err);
    return false;
  }
}

module.exports = {
  commands: ["del-palavrao"],
  description: "Remove uma ou mais palavras da lista de palavrões",
  usage: `${PREFIX}del-palavrao palavra1, palavra2, ...`,

  handle: async ({
    args,
    remoteJid,
    socket,
    sendSuccessReply,
    sendWarningReply,
    sendErrorReply,
    userJid,
  }) => {
    try {
      if (!isGroup(remoteJid)) {
        return sendWarningReply("Este comando só pode ser usado em grupos.");
      }

      const donoJid = "5511999999999@s.whatsapp.net"; // Altere para seu número
      const admin = await isAdmin(userJid, remoteJid, socket);
      const isBotOwner = userJid === donoJid;

      if (!admin && !isBotOwner) {
        return sendWarningReply("Apenas administradores ou o dono do bot podem usar este comando.");
      }

      const palavrasInput = args.join(" ");
      const palavrasRemover = palavrasInput
        .split(",")
        .map(p => p.trim().toLowerCase())
        .filter(p => p.length > 0);

      if (!palavrasRemover.length) {
        return sendWarningReply(`Use: ${PREFIX}del-palavrao palavra1, palavra2, ...`);
      }

      if (!fs.existsSync(filePath)) {
        return sendWarningReply("Ainda não há palavras adicionadas.");
      }

      const data = fs.readFileSync(filePath, "utf8");
      const json = JSON.parse(data);
      const palavras = json.global || [];

      const removidas = [];

      for (const palavra of palavrasRemover) {
        const index = palavras.indexOf(palavra);
        if (index !== -1) {
          palavras.splice(index, 1);
          removidas.push(palavra);
        }
      }

      if (removidas.length === 0) {
        return sendWarningReply("Nenhuma das palavras informadas estava na lista.");
      }

      json.global = palavras;
      fs.writeFileSync(filePath, JSON.stringify(json, null, 2));

      return sendSuccessReply(`Palavras removidas: ${removidas.join(", ")}`);
    } catch (err) {
      console.error("Erro ao remover palavras:", err);
      return sendErrorReply("Erro ao remover as palavras.");
    }
  },
};
