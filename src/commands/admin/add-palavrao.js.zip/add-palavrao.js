const fs = require("fs");
const path = require("path");
const { PREFIX } = require("../../config");

const filePath = path.resolve(__dirname, "../../../database/palavroes.json");

function isGroup(jid = "") {
  return jid.endsWith("@g.us");
}

async function isAdmin(userJid, groupJid, sock) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    const participant = metadata.participants.find(p => p.id === userJid);
    return participant?.admin === "admin" || participant?.admin === "superadmin";
  } catch (err) {
    console.error("Erro ao verificar admin:", err);
    return false;
  }
}

module.exports = {
  commands: ["add-palavrao"],
  description: "Adiciona uma ou mais palavras proibidas (ADM)",
  usage: `${PREFIX}add-palavrao palavra1, palavra2, ...`,

  handle: async ({
    args,
    remoteJid,
    socket,
    sendSuccessReply,
    sendWarningReply,
    sendErrorReply,
    userJid,
  }) => {
    try {
      if (!isGroup(remoteJid)) {
        return sendWarningReply("Este comando só pode ser usado em grupos.");
      }

      const donoJid = "55991888116@s.whatsapp.net"; // Altere para o seu número
      const admin = await isAdmin(userJid, remoteJid, socket);
      const isBotOwner = userJid === donoJid;

      if (!admin && !isBotOwner) {
        return sendWarningReply("Apenas administradores ou o dono do bot podem usar este comando.");
      }

      const palavrasInput = args.join(" ");
      const novasPalavras = palavrasInput
        .split(",")
        .map(p => p.trim().toLowerCase())
        .filter(p => p.length > 0);

      if (!novasPalavras.length) {
        return sendWarningReply(`Use: ${PREFIX}add-palavrao palavra1, palavra2, ...`);
      }

      let palavroes = { global: [] };

      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, "utf8");
        palavroes = JSON.parse(raw);
      }

      const adicionadas = [];

      for (const palavra of novasPalavras) {
        if (!palavroes.global.includes(palavra)) {
          palavroes.global.push(palavra);
          adicionadas.push(palavra);
        }
      }

      if (adicionadas.length === 0) {
        return sendWarningReply("Todas as palavras já estavam na lista.");
      }

      fs.writeFileSync(filePath, JSON.stringify(palavroes, null, 2));

      return sendSuccessReply(`Palavrões adicionados: ${adicionadas.join(", ")}`);
    } catch (err) {
      console.error("Erro ao adicionar palavrões:", err);
      return sendErrorReply("Erro ao adicionar palavrões.");
    }
  },
};
