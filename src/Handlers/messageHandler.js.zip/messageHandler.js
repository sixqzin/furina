// src/handlers/messageHandler.js

async function handleMessage(message, sock) {
try {
if (!message || typeof message !== "object") return;
if (!message.key || !message.key.remoteJid) return;

const textoOriginal =  
  message.message?.conversation ||  
  message.message?.extendedTextMessage?.text ||  
  message.message?.buttonsResponseMessage?.selectedButtonId ||  
  "";  

const comando = textoOriginal.trim().toLowerCase().split(" ")[0];  

if (comando === "/menu") {  
  // Ignora para evitar enviar menu duplicado  
  return;  
}  

// Outros comandos...

} catch (error) {
console.error("[TAKESHI BOT | ERROR] handleMessage:", error);
}
}

module.exports = { handleMessage };

